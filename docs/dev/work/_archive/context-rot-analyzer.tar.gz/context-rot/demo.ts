/**
 * demo.ts — 可直接运行的演示
 *
 * 模拟一个真实的 Claude Code 对话：
 * 用户最初想用 MySQL，中途改成 PostgreSQL，
 * 经历了几次失败尝试，最终测试通过。
 *
 * 运行：npx ts-node demo.ts
 * 或:   npx tsx demo.ts
 */

import { analyzeSession, printReport, saveReport } from "./src/index.js";
import type { NormalizedMessage } from "./src/index.js";

// ─── 模拟对话数据（覆盖所有决策类型） ────────────────────────────────────────

const mockSession: NormalizedMessage[] = [
  {
    id: "msg_001", index: 0, role: "system", tokens: 120,
    content: "You are an expert TypeScript developer. Help the user build a backend API.",
  },
  {
    id: "msg_002", index: 1, role: "user", tokens: 45,
    content: "我需要搭建一个用户管理系统，使用 MySQL 数据库，用 Express + TypeScript。",
  },
  {
    id: "msg_003", index: 2, role: "assistant", tokens: 280,
    content: `好的，我来帮你设计 MySQL 用户管理系统。
数据库 Schema：
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
我们使用 mysql2 驱动连接数据库。`,
  },
  {
    id: "msg_004", index: 3, role: "user", tokens: 20,
    content: "好的，先创建项目结构。",
  },
  {
    id: "msg_005", index: 4, role: "assistant", tokens: 150,
    content: `创建如下结构：
src/
  config/database.ts    # MySQL 连接配置
  models/user.ts        # User 模型
  routes/users.ts       # CRUD 路由
  app.ts                # Express 入口`,
  },
  {
    id: "msg_006", index: 5, role: "user", tokens: 18,
    content: "我发现公司环境只有 PostgreSQL，改一下，不用 MySQL 了，换成 PostgreSQL。",
  },
  {
    id: "msg_007", index: 6, role: "assistant", tokens: 220,
    content: `明白，切换到 PostgreSQL。更新 Schema：
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
使用 pg 驱动，连接配置更新为 PostgreSQL 格式。`,
  },
  {
    id: "msg_008", index: 7, role: "tool", isToolUse: true, toolUseId: "tool_abc", toolName: "write_file", tokens: 30,
    content: JSON.stringify({ tool: "write_file", path: "src/config/database.ts", action: "create" }),
  },
  {
    id: "msg_009", index: 8, role: "tool", isToolResult: true, toolUseId: "tool_abc", tokens: 45,
    content: "File written: src/config/database.ts (PostgreSQL pool configuration)",
  },
  {
    id: "msg_010", index: 9, role: "tool", isToolUse: true, toolUseId: "tool_def", toolName: "run_command", tokens: 20,
    content: JSON.stringify({ tool: "run_command", cmd: "npm install pg @types/pg" }),
  },
  {
    id: "msg_011", index: 10, role: "tool", isToolResult: true, toolUseId: "tool_def", tokens: 800,
    content: `added 47 packages, and audited 432 packages in 8s
found 0 vulnerabilities
npm warn deprecated inflight@1.0.6: This module is not supported, and leaks memory.
npm warn deprecated glob@7.2.3: Glob versions prior to v9 are no longer supported
npm warn deprecated rimraf@3.0.2: Rimraf versions prior to v4 are no longer supported
npm warn deprecated @humanwhocodes/config-array@0.11.14: Use @eslint/config-array instead
npm warn deprecated @humanwhocodes/object-schema@2.0.3: Use @eslint/object-schema instead
[... 大量安装日志省略 ...]
postgresql@14.10 Connected
`,
  },
  {
    id: "msg_012", index: 11, role: "assistant", tokens: 180,
    content: `依赖安装完成。现在实现 UserService：
// src/services/userService.ts
import { pool } from '../config/database';

export async function createUser(email: string, name: string) {
  const { rows } = await pool.query(
    'INSERT INTO users (email, name) VALUES ($1, $2) RETURNING *',
    [email, name]
  );
  return rows[0];
}`,
  },
  {
    id: "msg_013", index: 12, role: "user", tokens: 15,
    content: "运行测试看看。",
  },
  {
    id: "msg_014", index: 13, role: "tool", isToolUse: true, toolUseId: "tool_ghi", toolName: "run_tests", tokens: 25,
    content: JSON.stringify({ tool: "run_tests", cmd: "npm test" }),
  },
  {
    id: "msg_015", index: 14, role: "tool", isToolResult: true, toolUseId: "tool_ghi", tokens: 120,
    content: `FAIL src/services/userService.test.ts
  ● createUser › should create user
    Error: connect ECONNREFUSED 127.0.0.1:5432
    at TCPConnectWrap.afterConnect [as oncomplete]
    
Tests: 1 failed, 0 passed`,
  },
  {
    id: "msg_016", index: 15, role: "assistant", tokens: 90,
    content: `测试失败，PostgreSQL 连接被拒绝。问题：本地没有运行 PostgreSQL 服务。
解决方案：使用 Docker 启动 PostgreSQL。`,
  },
  {
    id: "msg_017", index: 16, role: "tool", isToolUse: true, toolUseId: "tool_jkl", toolName: "run_command", tokens: 30,
    content: JSON.stringify({ cmd: "docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=test postgres:15" }),
  },
  {
    id: "msg_018", index: 17, role: "tool", isToolResult: true, toolUseId: "tool_jkl", tokens: 25,
    content: "Container started: postgres:15 on port 5432",
  },
  {
    id: "msg_019", index: 18, role: "tool", isToolUse: true, toolUseId: "tool_mno", toolName: "run_tests", tokens: 20,
    content: JSON.stringify({ cmd: "npm test" }),
  },
  {
    id: "msg_020", index: 19, role: "tool", isToolResult: true, toolUseId: "tool_mno", tokens: 85,
    content: `PASS src/services/userService.test.ts
  ✓ createUser › should create user (234ms)
  ✓ createUser › should reject duplicate email (89ms)
  ✓ getUserById › should return user (45ms)

Tests: 3 passed, 3 passed ✅`,
  },
  {
    id: "msg_021", index: 20, role: "user", tokens: 22,
    content: "测试通过了！✅ 很好。以后所有数据库相关的代码都使用 PostgreSQL，不要再用 MySQL。",
  },
  {
    id: "msg_022", index: 21, role: "assistant", tokens: 60,
    content: "明白，项目已完全切换到 PostgreSQL。userService.ts 中的所有查询使用 pg 的 $1/$2 参数格式。",
  },
  {
    id: "msg_023", index: 22, role: "user", tokens: 18,
    content: "现在给 users 表加一个 role 字段，支持 'admin' 和 'member'。",
  },
  {
    id: "msg_024", index: 23, role: "assistant", tokens: 110,
    content: `好的，更新 PostgreSQL Schema：
ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'member';
CREATE INDEX idx_users_role ON users(role);
同时更新 createUser 函数支持 role 参数。`,
  },
];

// ─── 运行分析 ──────────────────────────────────────────────────────────────────

console.log("\n🔍 Running Context Rot Analysis...\n");

const report = analyzeSession(mockSession, "demo-session.jsonl");

// 命令行输出
printReport(report);

// 保存 JSON 报告
const savedPath = saveReport(report, "./reports");
console.log(`\n✅ Full JSON report saved to: ${savedPath}\n`);

// ─── 快速验证：关键断言 ────────────────────────────────────────────────────────

const { analyses } = report;
const decisions = Object.fromEntries(
  analyses.map(a => [a.index, a.decision])
);

console.log("─── Validation Checks ───────────────────────────────────");

function check(label: string, pass: boolean): void {
  const icon = pass ? "\x1b[32m✓\x1b[0m" : "\x1b[31m✗\x1b[0m";
  console.log(`  ${icon} ${label}`);
}

// system 消息必须保护
check("msg#0 (system) → keep_protected", decisions[0] === "keep_protected");

// MySQL 方案（index 2,4）应该是 remove 或 compress（被 PostgreSQL 覆盖了）
check("msg#2 (MySQL schema) → compress/remove", ["compress_candidate","remove_candidate"].includes(decisions[2]));

// 永久指令（以后都用 PostgreSQL）必须保护
check("msg#20 (永久指令) → keep_protected", decisions[20] === "keep_protected");

// 大型 npm 安装日志（未被引用）应该是 remove/compress
check("msg#10 (npm install log, 800 tokens) → compress/remove", ["compress_candidate","remove_candidate"].includes(decisions[10]));

// 测试通过结论应该保护
check("msg#19 (tests passed ✅) → keep_protected or keep", ["keep_protected","keep"].includes(decisions[19]));

// 最近的消息必须保护
check("msg#23 (recent) → keep_protected", decisions[23] === "keep_protected");

console.log("─────────────────────────────────────────────────────────\n");
