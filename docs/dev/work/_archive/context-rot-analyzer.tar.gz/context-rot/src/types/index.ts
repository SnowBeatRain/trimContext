// ─── Input: 与你现有项目对齐的消息结构 ───────────────────────────────────────

export type MessageRole = "system" | "user" | "assistant" | "tool";

export interface NormalizedMessage {
  id: string;
  index: number;
  role: MessageRole;
  content: string;
  timestamp?: string;

  // 工具调用相关
  toolUseId?: string;
  toolName?: string;
  isToolUse?: boolean;
  isToolResult?: boolean;

  tokens: number;
}

// ─── 中间层：关系图节点 ────────────────────────────────────────────────────────

export type RelationType = "tool_pair" | "entity_ref" | "supersedes" | "causal";

export interface MessageRelation {
  fromIndex: number;
  toIndex: number;
  type: RelationType;
  strength: number; // 0-1
  detail?: string;
}

// ─── 评分维度（每条消息） ──────────────────────────────────────────────────────

export interface RotDimensions {
  superseded: number;   // 被后续指令覆盖程度 0-1
  reference: number;    // 后续引用频率（越高越保留，取反后用于 rot） 0-1
  age: number;          // 时效性衰减 0-1
  redundancy: number;   // 与附近消息的重复度 0-1
  orphanTool: number;   // 工具孤儿程度 0-1（tool_result 未被引用）
}

export type Decision = "keep_protected" | "keep" | "compress_candidate" | "remove_candidate";

export interface MessageAnalysis {
  messageId: string;
  index: number;
  role: MessageRole;
  contentPreview: string; // 前 80 字符
  tokens: number;

  dimensions: RotDimensions;
  rotScore: number;       // 0-1 综合腐烂分
  confidence: number;     // 0-1 判断置信度
  decision: Decision;

  protectionReason?: string;   // 若 keep_protected，说明原因
  decisionReason: string;      // 人类可读的决策理由
  relations: MessageRelation[];
}

// ─── 最终报告 ─────────────────────────────────────────────────────────────────

export interface SessionReport {
  generatedAt: string;
  sourceFile?: string;

  stats: {
    totalMessages: number;
    totalTokens: number;
    protectedCount: number;
    keepCount: number;
    compressCount: number;
    removeCount: number;
    estimatedSavingsTokens: number;
    estimatedSavingsPct: number;
  };

  analyses: MessageAnalysis[];

  // 按决策分组，方便查阅
  summary: {
    protected: SummaryEntry[];
    remove: SummaryEntry[];
    compress: SummaryEntry[];
  };
}

export interface SummaryEntry {
  index: number;
  role: MessageRole;
  preview: string;
  tokens: number;
  rotScore: number;
  reason: string;
}
