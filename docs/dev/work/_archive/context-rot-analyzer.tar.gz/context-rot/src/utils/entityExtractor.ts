/**
 * 实体提取器
 * 从消息内容中提取可被后续消息引用的实体：
 * 文件路径、函数名、类名、错误信息、变量名、决策关键词
 */

export interface ExtractedEntities {
  filePaths: string[];
  functionNames: string[];
  classNames: string[];
  errorMessages: string[];
  variableNames: string[];
  decisionKeywords: string[];
}

// 覆盖性关键词（中英文）
const SUPERSEDE_PATTERNS = [
  /不(?:要|用|需要|再)\s*(.{2,20}?)(?:[了，。]|$)/g,
  /改(?:成|为|用)\s*(.{2,20}?)(?:[了，。\s]|$)/g,
  /换(?:成|为|用)\s*(.{2,20}?)(?:[了，。\s]|$)/g,
  /放弃\s*(.{2,20}?)(?:[了，。\s]|$)/g,
  /don'?t use\s+(\S+)/gi,
  /switch(?:ing)? (?:to|from)\s+(\S+)/gi,
  /replace\s+\S+\s+with\s+(\S+)/gi,
  /instead of\s+(\S+)/gi,
  /no longer\s+(\S+)/gi,
];

// 架构决策关键词（命中则提高保护权重）
const ARCHITECTURE_PATTERNS = [
  /architecture/i, /schema/i, /interface\s+\w+/i, /api\s+endpoint/i,
  /database/i, /数据库/,  /架构/, /接口定义/, /数据模型/,
  /design decision/i, /we decided/i, /从今以后/, /以后都/, /always use/i,
];

// 最终确认关键词
const CONFIRMATION_PATTERNS = [
  /测试通过/, /tests? (?:pass|green|ok)/i, /✓/, /✅/,
  /confirmed/i, /approved/i, /done$/im, /完成/, /好的，就这样/,
  /lgtm/i, /ship it/i,
];

export function extractEntities(content: string): ExtractedEntities {
  const filePaths = extractFilePaths(content);
  const functionNames = extractFunctionNames(content);
  const classNames = extractClassNames(content);
  const errorMessages = extractErrorMessages(content);
  const variableNames = extractVariableNames(content);
  const decisionKeywords = extractDecisionKeywords(content);

  return { filePaths, functionNames, classNames, errorMessages, variableNames, decisionKeywords };
}

function extractFilePaths(content: string): string[] {
  const patterns = [
    /(?:^|[\s`"'])([./~][\w./\-@]+\.(?:ts|tsx|js|jsx|py|json|yaml|yml|md|css|html|sh|env)[^"'\s`]*)/gm,
    /(?:src|lib|app|test|dist)\/[\w./\-]+/g,
  ];
  const results = new Set<string>();
  for (const p of patterns) {
    for (const m of content.matchAll(p)) {
      const path = (m[1] || m[0]).trim();
      if (path.length > 3 && path.length < 120) results.add(path);
    }
  }
  return [...results];
}

function extractFunctionNames(content: string): string[] {
  const patterns = [
    /(?:function|def|fn)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g,
    /([a-zA-Z_$][a-zA-Z0-9_$]*)\s*(?:=\s*)?(?:async\s*)?\([^)]{0,60}\)\s*(?:=>|{)/g,
    /`([a-zA-Z_$][a-zA-Z0-9_$]*)\(\)`/g, // backtick-wrapped function refs
  ];
  const results = new Set<string>();
  const skip = new Set(["if", "for", "while", "switch", "catch", "function", "return", "async", "await"]);
  for (const p of patterns) {
    for (const m of content.matchAll(p)) {
      const name = m[1];
      if (name && !skip.has(name) && name.length > 2) results.add(name);
    }
  }
  return [...results].slice(0, 20);
}

function extractClassNames(content: string): string[] {
  const results = new Set<string>();
  for (const m of content.matchAll(/(?:class|interface|type)\s+([A-Z][a-zA-Z0-9_]*)/g)) {
    results.add(m[1]);
  }
  // PascalCase words likely to be class refs
  for (const m of content.matchAll(/\b([A-Z][a-zA-Z]{2,}(?:[A-Z][a-zA-Z]+)*)\b/g)) {
    if (m[1].length < 40) results.add(m[1]);
  }
  return [...results].slice(0, 15);
}

function extractErrorMessages(content: string): string[] {
  const results = new Set<string>();
  const patterns = [
    /(?:Error|Exception|TypeError|ReferenceError|SyntaxError):\s*(.{10,80})/g,
    /(?:error|failed|failure):\s*(.{10,80})/gi,
    /Cannot\s+\w+.{5,60}/g,
    /\[ERROR\]\s*(.{5,80})/g,
  ];
  for (const p of patterns) {
    for (const m of content.matchAll(p)) {
      results.add((m[1] || m[0]).trim().slice(0, 80));
    }
  }
  return [...results].slice(0, 10);
}

function extractVariableNames(content: string): string[] {
  const results = new Set<string>();
  for (const m of content.matchAll(/(?:const|let|var)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g)) {
    if (m[1].length > 2) results.add(m[1]);
  }
  return [...results].slice(0, 15);
}

function extractDecisionKeywords(content: string): string[] {
  const keywords: string[] = [];
  for (const p of ARCHITECTURE_PATTERNS) {
    if (p.test(content)) keywords.push("architecture_decision");
  }
  for (const p of CONFIRMATION_PATTERNS) {
    if (p.test(content)) keywords.push("confirmed_conclusion");
  }
  for (const p of SUPERSEDE_PATTERNS) {
    const m = content.match(p);
    if (m) keywords.push(`supersedes:${m[0].slice(0, 30)}`);
  }
  return keywords;
}

export function isArchitectureDecision(content: string): boolean {
  return ARCHITECTURE_PATTERNS.some(p => p.test(content));
}

export function isConfirmedConclusion(content: string): boolean {
  return CONFIRMATION_PATTERNS.some(p => p.test(content));
}

export function containsSupersedeSignal(content: string): { found: boolean; targets: string[] } {
  const targets: string[] = [];
  for (const p of SUPERSEDE_PATTERNS) {
    for (const m of content.matchAll(p)) {
      if (m[1]) targets.push(m[1].trim());
    }
  }
  return { found: targets.length > 0, targets };
}

/**
 * 判断 haystack 中有多少 needle 里的实体被提及
 * 返回 0-1 的引用率
 */
export function referenceOverlap(needle: ExtractedEntities, haystack: string): number {
  const allTerms = [
    ...needle.filePaths,
    ...needle.functionNames,
    ...needle.classNames,
    ...needle.errorMessages.map(e => e.slice(0, 30)),
    ...needle.variableNames,
  ].filter(t => t.length > 2);

  if (allTerms.length === 0) return 0;

  let hits = 0;
  for (const term of allTerms) {
    if (haystack.includes(term)) hits++;
  }
  return hits / allTerms.length;
}
