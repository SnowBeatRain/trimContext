/**
 * Context Rot Analyzer — 公开 API
 *
 * 使用方式：
 *
 *   import { analyzeSession, printReport, saveReport } from "./src/index.js";
 *
 *   const report = analyzeSession(yourNormalizedMessages, "path/to/session.jsonl");
 *   printReport(report);
 *   const savedPath = saveReport(report, "./reports");
 */

export { analyzeSession } from "./analyzers/decisionEngine.js";
export { printReport, saveReport, saveSummaryReport } from "./reporters/cliReporter.js";
export { extractEntities } from "./utils/entityExtractor.js";
export { checkProtection } from "./analyzers/protectionRules.js";
export { scoreMessage, WEIGHTS } from "./analyzers/rotScorer.js";

export type {
  NormalizedMessage,
  MessageAnalysis,
  SessionReport,
  RotDimensions,
  Decision,
  MessageRelation,
  SummaryEntry,
} from "./types/index.js";
