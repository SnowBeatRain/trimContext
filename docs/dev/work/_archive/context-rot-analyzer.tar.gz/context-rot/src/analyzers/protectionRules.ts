/**
 * 保护规则引擎
 * 必须在 rot_score 计算之前执行。
 * 命中任何一条规则 → decision = "keep_protected"，不再参与删除候选。
 */

import type { NormalizedMessage } from "../types/index.js";
import { isArchitectureDecision, isConfirmedConclusion, containsSupersedeSignal } from "../utils/entityExtractor.js";

export interface ProtectionResult {
  isProtected: boolean;
  reason?: string;
}

// 最近几条消息强制保护
const RECENT_MESSAGES_WINDOW = 10;

// "永久指令"关键词
const PERMANENT_INSTRUCTION_PATTERNS = [
  /以后(?:都|每次|一律)/,
  /从今(?:以后|起)/,
  /永远(?:不?要|使用|保持)/,
  /always\s+(?:use|do|keep|make)/i,
  /never\s+(?:use|do|change)/i,
  /every\s+time/i,
  /from now on/i,
  /going forward/i,
];

// API/Schema 定义关键词（被删后 agent 会失去方向）
const API_SCHEMA_PATTERNS = [
  /(?:POST|GET|PUT|DELETE|PATCH)\s+\/\w+/,
  /endpoint[s]?\s*[:：]/i,
  /schema\s*[:：{]/i,
  /interface\s+\w+\s*{/,
  /type\s+\w+\s*=/,
  /CREATE TABLE/i,
  /ALTER TABLE/i,
  /数据库.*字段/,
  /表结构/,
];

export function checkProtection(
  msg: NormalizedMessage,
  allMessages: NormalizedMessage[],
  totalCount: number
): ProtectionResult {

  // 1. system / developer 消息
  if (msg.role === "system") {
    return { isProtected: true, reason: "system_message" };
  }

  // 2. 最近 N 条消息
  const fromEnd = totalCount - 1 - msg.index;
  if (fromEnd < RECENT_MESSAGES_WINDOW) {
    return { isProtected: true, reason: `recent_message (last ${fromEnd + 1})` };
  }

  // 3. 永久性指令
  for (const p of PERMANENT_INSTRUCTION_PATTERNS) {
    if (p.test(msg.content)) {
      return { isProtected: true, reason: "permanent_instruction" };
    }
  }

  // 4. 架构决策（被引用过，且没有被后续指令覆盖）
  if (isArchitectureDecision(msg.content)) {
    const laterMessages = allMessages.filter(m => m.index > msg.index);

    // 若被后续覆盖信号命中，不保护（交给 rot scorer 打高分）
    const isSuperseded = laterMessages.some(later => {
      const { found } = containsSupersedeSignal(later.content);
      if (!found) return false;
      return contentOverlapScore(msg.content, later.content) > 0.08;
    });
    if (isSuperseded) {
      return { isProtected: false };
    }

    const isReferenced = laterMessages.some(later =>
      later.content.length > 10 && contentOverlapScore(msg.content, later.content) > 0.15
    );
    if (isReferenced) {
      return { isProtected: true, reason: "architecture_decision_referenced" };
    }
  }

  // 5. API / Schema 定义
  for (const p of API_SCHEMA_PATTERNS) {
    if (p.test(msg.content)) {
      return { isProtected: true, reason: "api_or_schema_definition" };
    }
  }

  // 6. 用户确认的最终结论（且是 user 角色）
  if (msg.role === "user" && isConfirmedConclusion(msg.content)) {
    return { isProtected: true, reason: "user_confirmed_conclusion" };
  }

  // 7. tool_result 被后续多次引用（3次以上）
  if (msg.isToolResult) {
    const laterMessages = allMessages.filter(m => m.index > msg.index);
    const refCount = laterMessages.filter(later =>
      contentOverlapScore(msg.content, later.content) > 0.1
    ).length;
    if (refCount >= 3) {
      return { isProtected: true, reason: `tool_result_referenced_${refCount}x` };
    }
  }

  return { isProtected: false };
}

/**
 * 粗粒度内容重叠度（基于词汇共现，无需 embedding）
 */
function contentOverlapScore(a: string, b: string): number {
  const wordsA = tokenize(a);
  const wordsB = new Set(tokenize(b));
  if (wordsA.length === 0) return 0;
  const hits = wordsA.filter(w => wordsB.has(w)).length;
  return hits / wordsA.length;
}

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fa5]/g, " ") // 保留中文字符
    .split(/\s+/)
    .filter(w => w.length > 2); // 过滤短词
}
