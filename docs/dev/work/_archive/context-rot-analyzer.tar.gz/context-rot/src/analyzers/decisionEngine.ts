/**
 * 决策引擎
 * 执行顺序：保护规则 → rot_score × confidence → 最终 decision
 */

import type {
  NormalizedMessage,
  MessageAnalysis,
  Decision,
  SessionReport,
  SummaryEntry,
} from "../types/index.js";
import { checkProtection } from "./protectionRules.js";
import { scoreMessage } from "./rotScorer.js";

// 决策阈值（可调参）
const THRESHOLDS = {
  remove: { rotScore: 0.75, confidence: 0.65 },
  compress: { rotScore: 0.50, confidence: 0.45 },
};

export function analyzeSession(
  messages: NormalizedMessage[],
  sourceFile?: string
): SessionReport {
  const analyses: MessageAnalysis[] = [];
  const total = messages.length;

  for (const msg of messages) {
    const analysis = analyzeMessage(msg, messages, total);
    analyses.push(analysis);
  }

  return buildReport(analyses, messages, sourceFile);
}

function analyzeMessage(
  msg: NormalizedMessage,
  allMessages: NormalizedMessage[],
  totalCount: number
): MessageAnalysis {
  const preview = msg.content.slice(0, 80).replace(/\n/g, " ") + (msg.content.length > 80 ? "…" : "");

  // ── Step 1: 保护规则（优先） ────────────────────────────────────────────────
  const protection = checkProtection(msg, allMessages, totalCount);

  if (protection.isProtected) {
    return {
      messageId: msg.id,
      index: msg.index,
      role: msg.role,
      contentPreview: preview,
      tokens: msg.tokens,
      dimensions: { superseded: 0, reference: 0, age: 0, redundancy: 0, orphanTool: 0 },
      rotScore: 0,
      confidence: 1,
      decision: "keep_protected",
      protectionReason: protection.reason,
      decisionReason: `Protected: ${protection.reason}`,
      relations: [],
    };
  }

  // ── Step 2: 评分 ────────────────────────────────────────────────────────────
  const scoring = scoreMessage(msg, allMessages);
  const { rotScore, confidence, dimensions, relations } = scoring;

  // ── Step 3: 决策 ────────────────────────────────────────────────────────────
  const { decision, decisionReason } = makeDecision(rotScore, confidence, dimensions);

  return {
    messageId: msg.id,
    index: msg.index,
    role: msg.role,
    contentPreview: preview,
    tokens: msg.tokens,
    dimensions,
    rotScore,
    confidence,
    decision,
    decisionReason,
    relations,
  };
}

function makeDecision(
  rotScore: number,
  confidence: number,
  dims: ReturnType<typeof scoreMessage>["dimensions"]
): { decision: Decision; decisionReason: string } {

  // 高腐烂 + 高置信 → 删除候选
  if (rotScore >= THRESHOLDS.remove.rotScore && confidence >= THRESHOLDS.remove.confidence) {
    const reasons: string[] = [];
    if (dims.superseded > 0.6) reasons.push(`superseded(${pct(dims.superseded)})`);
    if (dims.reference > 0.6) reasons.push(`unreferenced(${pct(dims.reference)})`);
    if (dims.orphanTool > 0.6) reasons.push(`orphan_tool(${pct(dims.orphanTool)})`);
    if (dims.redundancy > 0.6) reasons.push(`redundant(${pct(dims.redundancy)})`);
    return {
      decision: "remove_candidate",
      decisionReason: reasons.length > 0
        ? `High rot [${reasons.join(", ")}]`
        : `rot=${pct(rotScore)}, conf=${pct(confidence)}`,
    };
  }

  // 高腐烂但低置信 → 保留（安全优先）
  if (rotScore >= THRESHOLDS.remove.rotScore && confidence < THRESHOLDS.remove.confidence) {
    return {
      decision: "keep",
      decisionReason: `high_rot_but_low_confidence (rot=${pct(rotScore)}, conf=${pct(confidence)})`,
    };
  }

  // 中等腐烂 + 足够置信 → 压缩候选
  if (rotScore >= THRESHOLDS.compress.rotScore && confidence >= THRESHOLDS.compress.confidence) {
    const mainDim = topDimension(dims);
    return {
      decision: "compress_candidate",
      decisionReason: `Moderate rot, main signal: ${mainDim} (rot=${pct(rotScore)})`,
    };
  }

  // 其余 → 保留
  return {
    decision: "keep",
    decisionReason: `Low rot score (${pct(rotScore)})`,
  };
}

// ─── 报告构建 ──────────────────────────────────────────────────────────────────

function buildReport(
  analyses: MessageAnalysis[],
  messages: NormalizedMessage[],
  sourceFile?: string
): SessionReport {
  const totalTokens = messages.reduce((s, m) => s + m.tokens, 0);

  const removeList = analyses.filter(a => a.decision === "remove_candidate");
  const compressList = analyses.filter(a => a.decision === "compress_candidate");
  const protectedList = analyses.filter(a => a.decision === "keep_protected");
  const keepList = analyses.filter(a => a.decision === "keep");

  const removableTokens = removeList.reduce((s, a) => s + a.tokens, 0);
  // 压缩预估节省 60%
  const compressTokens = Math.floor(compressList.reduce((s, a) => s + a.tokens, 0) * 0.6);
  const estimatedSavings = removableTokens + compressTokens;

  return {
    generatedAt: new Date().toISOString(),
    sourceFile,
    stats: {
      totalMessages: messages.length,
      totalTokens,
      protectedCount: protectedList.length,
      keepCount: keepList.length,
      compressCount: compressList.length,
      removeCount: removeList.length,
      estimatedSavingsTokens: estimatedSavings,
      estimatedSavingsPct: totalTokens > 0
        ? Math.round((estimatedSavings / totalTokens) * 100)
        : 0,
    },
    analyses,
    summary: {
      protected: protectedList.map(toSummaryEntry),
      remove: removeList.map(toSummaryEntry),
      compress: compressList.map(toSummaryEntry),
    },
  };
}

function toSummaryEntry(a: MessageAnalysis): SummaryEntry {
  return {
    index: a.index,
    role: a.role,
    preview: a.contentPreview,
    tokens: a.tokens,
    rotScore: a.rotScore,
    reason: a.decisionReason,
  };
}

function topDimension(dims: MessageAnalysis["dimensions"]): string {
  return Object.entries(dims)
    .sort(([, a], [, b]) => b - a)[0][0];
}

function pct(v: number): string {
  return `${Math.round(v * 100)}%`;
}
