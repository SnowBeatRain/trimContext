/**
 * Context Rot 评分引擎
 * 计算 5 个维度 → rot_score + confidence
 *
 * 维度权重（可调参）：
 *   superseded   0.30  被后续指令替代
 *   reference    0.25  后续引用缺失（取反）
 *   age          0.20  时效性衰减
 *   redundancy   0.15  与附近消息重复
 *   orphanTool   0.10  工具孤儿
 */

import type { NormalizedMessage, RotDimensions, MessageRelation } from "../types/index.js";
import {
  extractEntities,
  referenceOverlap,
  containsSupersedeSignal,
} from "../utils/entityExtractor.js";

export const WEIGHTS = {
  superseded: 0.30,
  reference: 0.25,   // 注意：这里是"低引用"的权重
  age: 0.20,
  redundancy: 0.15,
  orphanTool: 0.10,
};

export interface ScoringResult {
  dimensions: RotDimensions;
  rotScore: number;
  confidence: number;
  relations: MessageRelation[];
}

export function scoreMessage(
  msg: NormalizedMessage,
  allMessages: NormalizedMessage[]
): ScoringResult {
  const relations: MessageRelation[] = [];
  const totalCount = allMessages.length;
  const laterMessages = allMessages.filter(m => m.index > msg.index);
  const nearbyMessages = allMessages.filter(
    m => Math.abs(m.index - msg.index) <= 5 && m.index !== msg.index
  );

  // ── 维度 1：覆盖性 superseded ──────────────────────────────────────────────
  const superseded = computeSuperseded(msg, laterMessages, relations);

  // ── 维度 2：引用性 reference（低引用 = 高腐烂） ────────────────────────────
  const referenceScore = computeReference(msg, laterMessages, relations);
  const lowReference = 1 - referenceScore; // 转换为腐烂维度

  // ── 维度 3：时效性 age ──────────────────────────────────────────────────────
  const age = computeAge(msg.index, totalCount);

  // ── 维度 4：冗余性 redundancy ──────────────────────────────────────────────
  const redundancy = computeRedundancy(msg, nearbyMessages);

  // ── 维度 5：工具孤儿 orphanTool ────────────────────────────────────────────
  const orphanTool = computeOrphanTool(msg, allMessages, laterMessages, relations);

  const dimensions: RotDimensions = {
    superseded,
    reference: lowReference,
    age,
    redundancy,
    orphanTool,
  };

  // ── 综合 rot_score ──────────────────────────────────────────────────────────
  const rotScore =
    WEIGHTS.superseded * superseded +
    WEIGHTS.reference * lowReference +
    WEIGHTS.age * age +
    WEIGHTS.redundancy * redundancy +
    WEIGHTS.orphanTool * orphanTool;

  // ── 置信度 confidence ──────────────────────────────────────────────────────
  // 有效信号越多、消息越长（可分析内容越多），置信度越高
  const confidence = computeConfidence(msg, dimensions, laterMessages.length);

  return {
    dimensions,
    rotScore: clamp(rotScore),
    confidence: clamp(confidence),
    relations,
  };
}

// ─── 维度实现 ──────────────────────────────────────────────────────────────────

function computeSuperseded(
  msg: NormalizedMessage,
  laterMessages: NormalizedMessage[],
  relations: MessageRelation[]
): number {
  if (msg.role === "system") return 0;

  const entities = extractEntities(msg.content);
  let maxSupersede = 0;

  for (const later of laterMessages) {
    const { found, targets } = containsSupersedeSignal(later.content);
    if (!found) continue;

    // 检查覆盖目标是否涉及本消息的实体
    const allEntities = [
      ...entities.filePaths,
      ...entities.functionNames,
      ...entities.classNames,
      ...entities.variableNames,
    ];

    for (const target of targets) {
      const hit = allEntities.some(e =>
        e.toLowerCase().includes(target.toLowerCase()) ||
        target.toLowerCase().includes(e.toLowerCase())
      );
      if (hit) {
        const strength = 0.75 + (0.25 * (1 - (later.index - msg.index) / 100));
        maxSupersede = Math.max(maxSupersede, strength);
        relations.push({
          fromIndex: later.index,
          toIndex: msg.index,
          type: "supersedes",
          strength,
          detail: `"${target.slice(0, 40)}"`,
        });
        break;
      }
    }

    // 宽松匹配：相邻消息有明确覆盖信号且内容有重叠
    if (found && laterMessages.indexOf(later) < 5) {
      const overlap = roughOverlap(msg.content, later.content);
      if (overlap > 0.2) {
        maxSupersede = Math.max(maxSupersede, 0.5 * overlap);
      }
    }
  }

  return clamp(maxSupersede);
}

function computeReference(
  msg: NormalizedMessage,
  laterMessages: NormalizedMessage[],
  relations: MessageRelation[]
): number {
  if (laterMessages.length === 0) return 0.5; // 没有后续，不确定

  const entities = extractEntities(msg.content);
  const allLaterContent = laterMessages.map(m => m.content).join("\n");

  const overlap = referenceOverlap(entities, allLaterContent);

  // 按引用次数加权
  let refCount = 0;
  for (const later of laterMessages) {
    const o = referenceOverlap(entities, later.content);
    if (o > 0.1) {
      refCount++;
      relations.push({
        fromIndex: msg.index,
        toIndex: later.index,
        type: "entity_ref",
        strength: o,
      });
    }
  }

  // 综合：实体重叠 + 引用次数（多次引用是强信号）
  const countBonus = Math.min(refCount / 5, 0.4);
  return clamp(overlap * 0.6 + countBonus);
}

function computeAge(index: number, total: number): number {
  if (total <= 1) return 0;
  // 越早的消息衰减越高，但最大值限制在 0.6（单独不能决定删除）
  const rawAge = 1 - index / (total - 1);
  return rawAge * 0.6;
}

function computeRedundancy(
  msg: NormalizedMessage,
  nearbyMessages: NormalizedMessage[]
): number {
  if (nearbyMessages.length === 0) return 0;
  if (msg.content.length < 20) return 0;

  let maxSimilarity = 0;
  for (const near of nearbyMessages) {
    if (near.content.length < 20) continue;
    const sim = jaccardSimilarity(msg.content, near.content);
    maxSimilarity = Math.max(maxSimilarity, sim);
  }

  return clamp(maxSimilarity);
}

function computeOrphanTool(
  msg: NormalizedMessage,
  allMessages: NormalizedMessage[],
  laterMessages: NormalizedMessage[],
  relations: MessageRelation[]
): number {
  // 只对 tool_result 计算孤儿分
  if (!msg.isToolResult) return 0;

  // 1. 检查对应的 tool_use 是否存在
  const pairedUse = allMessages.find(
    m => m.isToolUse && m.toolUseId === msg.toolUseId
  );
  if (!pairedUse) return 0.4; // 找不到对应 use，轻度孤儿

  // 2. 检查 tool_result 内容是否被后续引用
  if (laterMessages.length === 0) return 0.6;

  const entities = extractEntities(msg.content);
  const allLaterContent = laterMessages.map(m => m.content).join("\n");
  const refScore = referenceOverlap(entities, allLaterContent);

  if (refScore > 0.15) {
    relations.push({
      fromIndex: msg.index,
      toIndex: laterMessages[0].index,
      type: "tool_pair",
      strength: refScore,
      detail: msg.toolName,
    });
    return 0; // 被引用了，不孤儿
  }

  // 3. 长篇工具结果且无引用 → 高孤儿分
  const isLarge = msg.tokens > 500;
  return isLarge ? 0.85 : 0.55;
}

// ─── 置信度计算 ────────────────────────────────────────────────────────────────

function computeConfidence(
  msg: NormalizedMessage,
  dims: RotDimensions,
  laterCount: number
): number {
  let confidence = 0.5; // 基准

  // 消息内容足够长，可以做分析
  if (msg.content.length > 100) confidence += 0.1;
  if (msg.content.length > 500) confidence += 0.1;

  // 有后续消息可以做引用分析
  if (laterCount > 5) confidence += 0.1;
  if (laterCount > 20) confidence += 0.05;

  // 多个维度指向同一方向（信号一致）→ 置信度更高
  const highDims = Object.values(dims).filter(v => v > 0.6).length;
  if (highDims >= 3) confidence += 0.15;

  // tool_result 有明确的孤儿/非孤儿判断
  if (msg.isToolResult && (dims.orphanTool > 0.7 || dims.orphanTool === 0)) {
    confidence += 0.1;
  }

  // 短消息难以分析
  if (msg.content.length < 30) confidence -= 0.2;

  return clamp(confidence);
}

// ─── 工具函数 ──────────────────────────────────────────────────────────────────

function jaccardSimilarity(a: string, b: string): number {
  const setA = new Set(ngrams(a, 3));
  const setB = new Set(ngrams(b, 3));
  if (setA.size === 0 && setB.size === 0) return 0;

  let intersection = 0;
  for (const g of setA) {
    if (setB.has(g)) intersection++;
  }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

function ngrams(text: string, n: number): string[] {
  const words = text.toLowerCase().split(/\s+/).filter(w => w.length > 1);
  const result: string[] = [];
  for (let i = 0; i <= words.length - n; i++) {
    result.push(words.slice(i, i + n).join(" "));
  }
  return result;
}

function roughOverlap(a: string, b: string): number {
  const wordsA = new Set(a.toLowerCase().split(/\W+/).filter(w => w.length > 3));
  const wordsB = new Set(b.toLowerCase().split(/\W+/).filter(w => w.length > 3));
  if (wordsA.size === 0) return 0;
  let hits = 0;
  for (const w of wordsA) if (wordsB.has(w)) hits++;
  return hits / wordsA.size;
}

function clamp(v: number): number {
  return Math.max(0, Math.min(1, v));
}
