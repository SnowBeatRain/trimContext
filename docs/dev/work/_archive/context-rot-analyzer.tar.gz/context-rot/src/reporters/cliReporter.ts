/**
 * 报告输出器
 * - 命令行彩色摘要（人类可读）
 * - JSON 文件留存（可回溯）
 */

import { writeFileSync, mkdirSync } from "fs";
import { join, basename } from "path";
import type { SessionReport, MessageAnalysis, SummaryEntry } from "../types/index.js";

// ─── ANSI 颜色 ──────────────────────────────────────────────────────────────
const C = {
  reset:   "\x1b[0m",
  bold:    "\x1b[1m",
  dim:     "\x1b[2m",
  red:     "\x1b[31m",
  green:   "\x1b[32m",
  yellow:  "\x1b[33m",
  blue:    "\x1b[34m",
  cyan:    "\x1b[36m",
  white:   "\x1b[37m",
  bgRed:   "\x1b[41m",
  bgGreen: "\x1b[42m",
  bgBlue:  "\x1b[44m",
};

const nc = (s: string) => s.replace(/\x1b\[[0-9;]*m/g, "");

function c(color: keyof typeof C, text: string): string {
  return `${C[color]}${text}${C.reset}`;
}

function bold(text: string): string {
  return `${C.bold}${text}${C.reset}`;
}

function bar(value: number, width = 20): string {
  const filled = Math.round(value * width);
  const empty = width - filled;
  const color = value >= 0.75 ? "red" : value >= 0.5 ? "yellow" : "green";
  return c(color, "█".repeat(filled)) + c("dim", "░".repeat(empty));
}

function decisionBadge(decision: MessageAnalysis["decision"]): string {
  switch (decision) {
    case "keep_protected":    return c("green",  "  PROTECTED  ");
    case "keep":              return c("cyan",   "    KEEP     ");
    case "compress_candidate":return c("yellow", "  COMPRESS   ");
    case "remove_candidate":  return c("red",    "   REMOVE    ");
  }
}

function roleBadge(role: string): string {
  switch (role) {
    case "system":    return c("blue",   "[SYS ]");
    case "user":      return c("cyan",   "[USER]");
    case "assistant": return c("white",  "[ASST]");
    case "tool":      return c("yellow", "[TOOL]");
    default:          return c("dim",    `[${role.slice(0,4).toUpperCase()}]`);
  }
}

// ─── 主输出函数 ────────────────────────────────────────────────────────────────

export function printReport(report: SessionReport): void {
  const { stats, analyses, summary } = report;

  printHeader(report);
  printStats(stats);
  printHealthBar(stats);

  if (summary.remove.length > 0) {
    printSection("🗑  Remove Candidates", summary.remove, "red");
  }
  if (summary.compress.length > 0) {
    printSection("📦  Compress Candidates", summary.compress, "yellow");
  }
  if (summary.protected.length > 0 && summary.protected.length <= 10) {
    printSection("🔒  Protected Messages", summary.protected, "green");
  } else if (summary.protected.length > 10) {
    console.log(`\n${bold("🔒  Protected:")} ${summary.protected.length} messages (showing first 5)`);
    printEntries(summary.protected.slice(0, 5), "green");
  }

  printFooter(report);
}

function printHeader(report: SessionReport): void {
  const width = 64;
  console.log("\n" + bold(c("blue", "─".repeat(width))));
  console.log(bold(c("blue", "  Context Rot Analyzer")));
  if (report.sourceFile) {
    console.log(c("dim", `  ${report.sourceFile}`));
  }
  console.log(c("dim", `  Generated: ${new Date(report.generatedAt).toLocaleString()}`));
  console.log(bold(c("blue", "─".repeat(width))));
}

function printStats(stats: SessionReport["stats"]): void {
  console.log("");
  console.log(bold("  Session Overview"));
  console.log("");

  const rows = [
    ["Messages",   String(stats.totalMessages)],
    ["Total Tokens", stats.totalTokens.toLocaleString()],
    ["Protected",   c("green",  String(stats.protectedCount))],
    ["Keep",        c("cyan",   String(stats.keepCount))],
    ["Compress",    c("yellow", String(stats.compressCount))],
    ["Remove",      c("red",    String(stats.removeCount))],
  ];

  for (const [label, value] of rows) {
    const pad = " ".repeat(Math.max(0, 16 - nc(label).length));
    console.log(`    ${c("dim", label)}${pad}${value}`);
  }

  console.log("");
  console.log(bold("  Estimated Savings"));
  console.log("");
  console.log(`    ${c("dim", "Tokens saved")}    ${c("green", stats.estimatedSavingsTokens.toLocaleString())} tokens`);
  console.log(`    ${c("dim", "Savings")}         ${c("green", bold(`${stats.estimatedSavingsPct}%`))}`);
}

function printHealthBar(stats: SessionReport["stats"]): void {
  const total = stats.totalMessages;
  if (total === 0) return;

  const pProtected = stats.protectedCount / total;
  const pKeep      = stats.keepCount / total;
  const pCompress  = stats.compressCount / total;
  const pRemove    = stats.removeCount / total;

  const width = 50;
  const wProtected = Math.round(pProtected * width);
  const wKeep      = Math.round(pKeep * width);
  const wCompress  = Math.round(pCompress * width);
  const wRemove    = width - wProtected - wKeep - wCompress;

  const healthBar =
    c("green",  "█".repeat(wProtected)) +
    c("cyan",   "█".repeat(wKeep)) +
    c("yellow", "█".repeat(wCompress)) +
    c("red",    "█".repeat(Math.max(0, wRemove)));

  console.log("");
  console.log(bold("  Context Health"));
  console.log("");
  console.log(`    ${healthBar}`);
  console.log(
    c("dim", `    `) +
    c("green",  "█ Protected ") +
    c("cyan",   "█ Keep ") +
    c("yellow", "█ Compress ") +
    c("red",    "█ Remove")
  );
}

function printSection(title: string, entries: SummaryEntry[], color: keyof typeof C): void {
  console.log("\n" + bold(`  ${title}`));
  printEntries(entries, color);
}

function printEntries(entries: SummaryEntry[], color: keyof typeof C): void {
  console.log("");
  for (const entry of entries) {
    const idx    = c("dim", `#${String(entry.index).padStart(3, "0")}`);
    const role   = roleBadge(entry.role);
    const tokens = c("dim", `${entry.tokens}t`);
    const score  = entry.rotScore > 0
      ? ` rot=${c(color, `${Math.round(entry.rotScore * 100)}%`)}`
      : "";
    const preview = c("dim", `"${entry.preview.slice(0, 55)}"`);

    console.log(`    ${idx} ${role} ${tokens}${score}`);
    console.log(`         ${preview}`);
    console.log(c("dim", `         ${entry.reason}`));
    console.log("");
  }
}

function printFooter(report: SessionReport): void {
  console.log(bold(c("blue", "─".repeat(64))));
  if (report.sourceFile) {
    const jsonPath = report.sourceFile.replace(/\.[^.]+$/, "") + ".rot-report.json";
    console.log(c("dim", `  Full report: ${jsonPath}`));
  }
  console.log("");
}

// ─── JSON 留存 ────────────────────────────────────────────────────────────────

export function saveReport(report: SessionReport, outputDir = "."): string {
  mkdirSync(outputDir, { recursive: true });

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const baseName = report.sourceFile
    ? basename(report.sourceFile).replace(/\.[^.]+$/, "")
    : "session";

  const filename = `${baseName}.${timestamp}.rot-report.json`;
  const outputPath = join(outputDir, filename);

  writeFileSync(outputPath, JSON.stringify(report, null, 2), "utf-8");
  return outputPath;
}

/**
 * 精简版 JSON（不含全量 analyses，只含摘要和候选列表）
 * 适合嵌入 CI 或自动化流水线
 */
export function saveSummaryReport(report: SessionReport, outputDir = "."): string {
  mkdirSync(outputDir, { recursive: true });

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const baseName = report.sourceFile
    ? basename(report.sourceFile).replace(/\.[^.]+$/, "")
    : "session";

  const filename = `${baseName}.${timestamp}.rot-summary.json`;
  const outputPath = join(outputDir, filename);

  const slim = {
    generatedAt: report.generatedAt,
    sourceFile: report.sourceFile,
    stats: report.stats,
    summary: report.summary,
  };

  writeFileSync(outputPath, JSON.stringify(slim, null, 2), "utf-8");
  return outputPath;
}
